var list = document.querySelector('.list');
var normal = document.querySelector('.normal');
var reverse = document.querySelector('.reverse');


var buttom = document.getElementById('normal').addEventListener('click', 
						function(){
						list.style.flexDirection = 'column';
						normal.style.background = '#ccc';
						reverse.style.background = '#ffaa00';
						});

var buttom = document.getElementById('reverse').addEventListener('click', 
						function(){
						list.style.flexDirection = 'column-reverse';
						normal.style.background = '#ffaa00';
						reverse.style.background = '#ccc';
						});
			


//MARXA

var img = document.getElementById('marxa').addEventListener('click', 
						function(){
						document.querySelector('.marxa').style.display = 'flex';
						});

		document.querySelector('.close').addEventListener('click', 				function(){
							document.querySelector('.marxa').style.display = 'none';
						});

//BLINDAJE

var img = document.getElementById('blindaje').addEventListener('click', 
						function(){
						document.querySelector('.blindaje').style.display = 'flex';
						});

						document.querySelector('.c-blindaje').addEventListener('click', function(){
							document.querySelector('.blindaje').style.display = 'none';
						});

//ZIN

var img = document.getElementById('zin').addEventListener('click', 
						function(){
						document.querySelector('.zin').style.display = 'flex';
						});

						document.querySelector('.c-zin').addEventListener('click', function(){
							document.querySelector('.zin').style.display = 'none';
						});

//showtime

var img = document.getElementById('showtime').addEventListener('click', 
						function(){
						document.querySelector('.showtime').style.display = 'flex';
						});

						document.querySelector('.c-showtime').addEventListener('click', function(){
							document.querySelector('.showtime').style.display = 'none';
						});

//disco

var img = document.getElementById('disco').addEventListener('click', 
						function(){
						document.querySelector('.disco').style.display = 'flex';
						});

						document.querySelector('.c-disco').addEventListener('click', function(){
							document.querySelector('.disco').style.display = 'none';
						});

//rec

var img = document.getElementById('rec').addEventListener('click', 
						function(){
						document.querySelector('.rec').style.display = 'flex';
						});

						document.querySelector('.c-rec').addEventListener('click', function(){
							document.querySelector('.rec').style.display = 'none';
						});

//endarpegio

var img = document.getElementById('endarpegio').addEventListener('click', 
						function(){
						document.querySelector('.endarpegio').style.display = 'flex';
						});

						document.querySelector('.c-endarpegio').addEventListener('click', function(){
							document.querySelector('.endarpegio').style.display = 'none';
						});

//titulo

var img = document.getElementById('titulo').addEventListener('click', 
						function(){
						document.querySelector('.titulo').style.display = 'flex';
						});

						document.querySelector('.c-titulo').addEventListener('click', function(){
							document.querySelector('.titulo').style.display = 'none';
						});

//arpegio

var img = document.getElementById('arpegio').addEventListener('click', 
						function(){
						document.querySelector('.arpegio').style.display = 'flex';
						});

						document.querySelector('.c-arpegio').addEventListener('click', function(){
							document.querySelector('.arpegio').style.display = 'none';
						});

//atu

var img = document.getElementById('atu').addEventListener('click', 
						function(){
						document.querySelector('.atu').style.display = 'flex';
						});

						document.querySelector('.c-atu').addEventListener('click', function(){
							document.querySelector('.atu').style.display = 'none';
						});

//nomasb

var img = document.getElementById('nomasb').addEventListener('click', 
						function(){
						document.querySelector('.nomasb').style.display = 'flex';
						});

						document.querySelector('.c-nomasb').addEventListener('click', function(){
							document.querySelector('.nomasb').style.display = 'none';
						});

//wwrypt

var img = document.getElementById('wwrypt').addEventListener('click', 
						function(){
						document.querySelector('.wwrypt').style.display = 'flex';
						});

						document.querySelector('.c-wwrypt').addEventListener('click', function(){
							document.querySelector('.wwrypt').style.display = 'none';
						});

//fincv

var img = document.getElementById('fincv').addEventListener('click', 
						function(){
						document.querySelector('.fincv').style.display = 'flex';
						});

						document.querySelector('.c-fincv').addEventListener('click', function(){
							document.querySelector('.fincv').style.display = 'none';
						});

//grease

var img = document.getElementById('grease').addEventListener('click', 
						function(){
						document.querySelector('.grease').style.display = 'flex';
						});

						document.querySelector('.c-grease').addEventListener('click', function(){
							document.querySelector('.grease').style.display = 'none';
						});

//iniciocv

var img = document.getElementById('iniciocv').addEventListener('click', 
						function(){
						document.querySelector('.iniciocv').style.display = 'flex';
						});

						document.querySelector('.c-iniciocv').addEventListener('click', function(){
							document.querySelector('.iniciocv').style.display = 'none';
						});

//wwry

var img = document.getElementById('wwry').addEventListener('click', 
						function(){
						document.querySelector('.wwry').style.display = 'flex';
						});

						document.querySelector('.c-wwry').addEventListener('click', function(){
							document.querySelector('.wwry').style.display = 'none';
						});

//iberia

var img = document.getElementById('iberia').addEventListener('click', 
						function(){
						document.querySelector('.iberia').style.display = 'flex';
						});

						document.querySelector('.c-iberia').addEventListener('click', function(){
							document.querySelector('.iberia').style.display = 'none';
						});

var img = document.getElementById('mamma').addEventListener('click', 
						function(){
						document.querySelector('.mamma').style.display = 'flex';
						});

						document.querySelector('.c-mamma').addEventListener('click', function(){
							document.querySelector('.mamma').style.display = 'none';
						});

var img = document.getElementById('hairspray').addEventListener('click', 
						function(){
						document.querySelector('.hairspray').style.display = 'flex';
						});

						document.querySelector('.c-hairspray').addEventListener('click', function(){
							document.querySelector('.hairspray').style.display = 'none';
						});